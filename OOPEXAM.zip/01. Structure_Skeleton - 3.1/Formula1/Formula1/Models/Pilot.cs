﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;
using Formula1.Models.Contracts;

namespace Formula1.Models
{
    public class Pilot : IPilot
    {
        public Pilot(string fullName)
        {
            FullName = fullName;
        }
        private string fullName;
        private IFormulaOneCar car;
        private int numberOfWins;
        private bool canRace;
        public string FullName
        {
            get => fullName;
            private set
            {
                if (string.IsNullOrWhiteSpace(value) || value.Length < 5)
                {
                    throw new ArgumentException(string.Format(Utilities.ExceptionMessages.InvalidPilot, value));
                }

                fullName = value;
            }
        }
        public IFormulaOneCar Car
        {
            get => car;
            private set
            {
                if (value == null)
                {
                    throw new NullReferenceException(Utilities.ExceptionMessages.InvalidCarForPilot);
                }

                car = value;
            }
        }
        public int NumberOfWins
        {
            get => numberOfWins;
            private set => numberOfWins = value;
        }
        public bool CanRace                                                                         //possible protected prop
        {
            get => canRace;
            private set
            {
                canRace = value;
            }
        }
        public void AddCar(IFormulaOneCar car)
        {
            Car = car;
            CanRace = true;
        }

        public void WinRace()
        {
            NumberOfWins += 1;
        }

        public override string ToString()
        {
            return $"Pilot {this.fullName} has {numberOfWins} wins.";
        }
    }
}
