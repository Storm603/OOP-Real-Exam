﻿using System;
using System.Collections.Generic;
using System.Text;
using Formula1.Models.Contracts;

namespace Formula1.Models
{
    public class Race : IRace
    {
        public Race(string raceName, int numberOfLaps)
        {
            RaceName = raceName;
            NumberOfLaps = numberOfLaps;
            pilots = new List<IPilot>();
        }

        private string raceName;
        private int numberOfLaps;
        private bool tookPlace;
        private List<IPilot> pilots;
        public string RaceName
        {
            get => raceName;
            private set
            {
                if (string.IsNullOrWhiteSpace(value) || value.Length < 5)
                {
                    throw new ArgumentException(string.Format(Utilities.ExceptionMessages.InvalidRaceName, value));
                }

                raceName = value;
            }
        }
        public int NumberOfLaps
        {
            get => numberOfLaps;
            private set
            {
                if (value < 1)
                {
                    throw new ArgumentException(string.Format(Utilities.ExceptionMessages.InvalidLapNumbers, value));
                }

                numberOfLaps = value;
            }
        }
        public bool TookPlace
        {
            get => tookPlace;
            set => tookPlace = value;                                                       // public setter?
        }

        public ICollection<IPilot> Pilots => pilots;
        public void AddPilot(IPilot pilot)
        {
            pilots.Add(pilot);
        }

        public string RaceInfo()
        {
            StringBuilder raceInfo = new StringBuilder();

            raceInfo.AppendLine($"The {raceName} race has:");
            raceInfo.AppendLine($"Participants: {pilots.Count}");
            raceInfo.AppendLine($"Number of laps: {numberOfLaps}");
            raceInfo.AppendLine($"Took place: {(tookPlace ? "Yes" : "No")}");

            return raceInfo.ToString().Trim();
        }
    }
}
