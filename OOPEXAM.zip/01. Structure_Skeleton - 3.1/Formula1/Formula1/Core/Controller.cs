﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Formula1.Core.Contracts;
using Formula1.Models;
using Formula1.Models.Contracts;
using Formula1.Repositories;

namespace Formula1.Core
{
    public class Controller :IController
    {
        public Controller()
        {
            pilotRepository = new PilotRepository();
            raceRepository = new RaceRepository();
            carRepository = new FormulaOneCarRepository();
        }

        private PilotRepository pilotRepository;
        private RaceRepository raceRepository;
        private FormulaOneCarRepository carRepository;
        public string CreatePilot(string fullName)
        {
            IPilot pilot = pilotRepository.FindByName(fullName);

            if (pilot != null)
            {
                throw new InvalidOperationException(string.Format(Utilities.ExceptionMessages.PilotExistErrorMessage,
                    fullName));
            }

            pilot = new Pilot(fullName);
            pilotRepository.Add(pilot);
            return string.Format(Utilities.OutputMessages.SuccessfullyCreatePilot, fullName);
        }

        public string CreateCar(string type, string model, int horsepower, double engineDisplacement)
        {
            IFormulaOneCar car = carRepository.FindByName(model);                                                   // possible mistake

            if (car != null)
            {
                throw new InvalidOperationException(string.Format(Utilities.ExceptionMessages.CarExistErrorMessage,
                    model));
            }

            if (type == "Ferrari")
            {
                car = new Ferrari(model, horsepower, engineDisplacement);
            }
            else if (type == "Williams")
            {
                car = new Williams(model, horsepower, engineDisplacement);
            }
            else
            {
                throw new InvalidOperationException(string.Format(Utilities.ExceptionMessages.InvalidTypeCar, type));
            }

            carRepository.Add(car);
            return string.Format(Utilities.OutputMessages.SuccessfullyCreateCar, type, model);
        }

        public string CreateRace(string raceName, int numberOfLaps)
        {
            IRace race = raceRepository.FindByName(raceName);

            if (race != null)
            {
                throw new InvalidOperationException(string.Format(Utilities.ExceptionMessages.RaceExistErrorMessage, raceName));
            }

            race = new Race(raceName, numberOfLaps);

            raceRepository.Add(race);
            return string.Format(Utilities.OutputMessages.SuccessfullyCreateRace, raceName);
        }

        public string AddCarToPilot(string pilotName, string carModel)
        {
            IPilot pilot = pilotRepository.FindByName(pilotName);
            IFormulaOneCar car = carRepository.FindByName(carModel);

            if (pilot == null || pilot.Car != null)
            {
                throw new InvalidOperationException(string.Format(Utilities.ExceptionMessages.PilotDoesNotExistOrHasCarErrorMessage,
                    pilotName));
            }

            if (car == null)
            {
                throw new NullReferenceException(string.Format(Utilities.ExceptionMessages.CarDoesNotExistErrorMessage,
                    carModel));
            }

            pilot.AddCar(car);
            carRepository.Remove(car);
            return string.Format(Utilities.OutputMessages.SuccessfullyPilotToCar, pilotName,
                car.GetType().Name, carModel);
        }

        public string AddPilotToRace(string raceName, string pilotFullName)
        {
            IPilot pilot = pilotRepository.FindByName(pilotFullName);
            IRace race = raceRepository.FindByName(raceName);

            if (race == null)
            {
                throw new NullReferenceException(string.Format(Utilities.ExceptionMessages.RaceDoesNotExistErrorMessage,
                    raceName));
            }

            if (pilot == null || !pilot.CanRace || race.Pilots.Contains(pilot))
            {
                throw new InvalidOperationException(
                    string.Format(Utilities.ExceptionMessages.PilotDoesNotExistErrorMessage, pilotFullName));
            }

            race.AddPilot(pilot);

            return string.Format(Utilities.OutputMessages.SuccessfullyAddPilotToRace, pilotFullName, raceName);
        }

        public string StartRace(string raceName)
        {
            IRace race = raceRepository.FindByName(raceName);

            if (race == null)
            {
                throw new NullReferenceException(string.Format(Utilities.ExceptionMessages.RaceDoesNotExistErrorMessage,
                    raceName));
            }

            if (race.Pilots.Count < 3)
            {
                throw new InvalidOperationException(string.Format(Utilities.ExceptionMessages.InvalidRaceParticipants,
                    raceName));
            }

            if (race.TookPlace)
            {
                throw new InvalidOperationException(string.Format(Utilities.ExceptionMessages.RaceTookPlaceErrorMessage,
                    raceName));
            }

            List<IPilot> pilotResults = race.Pilots
                .OrderByDescending(x => x.Car.RaceScoreCalculator(race.NumberOfLaps)).ToList();
            
            race.TookPlace = true;

            StringBuilder sb = new StringBuilder();

            sb.AppendLine(string.Format(Utilities.OutputMessages.PilotFirstPlace, pilotResults[0].FullName, raceName));         // MIGHT REVERSE
            sb.AppendLine(string.Format(Utilities.OutputMessages.PilotSecondPlace, pilotResults[1].FullName, raceName));
            sb.AppendLine(string.Format(Utilities.OutputMessages.PilotThirdPlace, pilotResults[2].FullName, raceName));

            pilotResults[0].WinRace();

            return sb.ToString().Trim();
        }

        public string RaceReport()
        {
            StringBuilder sb = new StringBuilder();

            foreach (IRace race in raceRepository.Models)
            {
                if (race.TookPlace)
                {
                    sb.AppendLine(race.RaceInfo());
                }
            }

            return sb.ToString().Trim();
        }

        public string PilotReport()
        {
            StringBuilder sb = new StringBuilder();

            foreach (IPilot pilot in pilotRepository.Models.OrderByDescending(x => x.NumberOfWins))
            {
                sb.AppendLine(pilot.ToString());
            }

            return sb.ToString().Trim();
        }
    }
}
