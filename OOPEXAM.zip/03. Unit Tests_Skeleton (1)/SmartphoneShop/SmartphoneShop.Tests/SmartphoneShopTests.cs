﻿using System;
using NUnit.Framework;

namespace SmartphoneShop.Tests
{
    [TestFixture]
    public class SmartphoneShopTests
    {
        [Test]
        public void Testing_Capacity()
        {
            Shop shop = new Shop(3);

            Assert.That(shop.Capacity == 3);
        }

        [Test]
        public void Testing_Capacity_Minus()
        {
            Assert.Throws<ArgumentException>(() => new Shop(-1));
        }

        [Test]
        public void Testing_Count()
        {
            Shop shop = new Shop(3);

            Smartphone phone = new Smartphone("samsung", 100);

            shop.Add(phone);

            Assert.That(shop.Count == 1);
        }

        [Test]
        public void Testing_Add_Exception_If_It_Exists()
        {
            Shop shop = new Shop(3);

            Smartphone phone = new Smartphone("samsung", 100);

            shop.Add(phone);

            Assert.Throws<InvalidOperationException>(() => shop.Add(phone));
        }

        [Test]
        public void Testing_Add_Capacity()
        {
            Shop shop = new Shop(3);

            shop.Add(new Smartphone("Samsung", 100));
            shop.Add(new Smartphone("Huawei", 100));
            shop.Add(new Smartphone("LG", 100));
            Assert.Throws<InvalidOperationException>(() => shop.Add(new Smartphone("Error", 100)));
        }

        [Test]
        public void Testing_Add_Happy_Case()
        {
            Shop shop = new Shop(3);

            Smartphone phone = new Smartphone("samsung", 100);

            shop.Add(phone);

            Assert.That(shop.Count == 1);
        }

        [Test]
        public void Testing_Remove_ExceptionIfItDoesntExist()
        {
            Shop shop = new Shop(3);

            Assert.Throws<InvalidOperationException>(() => shop.Remove("Nonexistent"));
        }

        [Test]
        public void Testing_Remove_Happy_Case()
        {
            Shop shop = new Shop(3);

            Smartphone phone = new Smartphone("samsung", 100);

            shop.Add(phone);

            Assert.That(shop.Count == 1);

            shop.Remove("samsung");

            Assert.That(shop.Count == 0);
        }

        [Test]
        public void Test_Phone_If_Null()
        {
            Shop shop = new Shop(3);

            Assert.Throws<InvalidOperationException>(() => shop.TestPhone("sam", 100));
        }

        [Test]
        public void Test_Phone_ExceptionBatteryCharge()
        {
            Shop shop = new Shop(3);

            Smartphone phone = new Smartphone("sam", 80);

            shop.Add(phone);

            Assert.Throws<InvalidOperationException>(() => shop.TestPhone("sam", 100));
        }

        [Test]
        public void TestPhoneMethod_HappyCase()
        {
            Shop shop = new Shop(3);

            Smartphone phone = new Smartphone("sam", 80);

            shop.Add(phone);

            shop.TestPhone("sam", 50);

            Assert.That(phone.CurrentBateryCharge == 30);
        }

        [Test]
        public void Test_Charge_Phone_Null()
        {
            Shop shop = new Shop(3);

            Assert.Throws<InvalidOperationException>(() => shop.ChargePhone("sami"));
        }

        [Test]
        public void Test_Charge_Phone_HappyCase()
        {
            Shop shop = new Shop(3);

            Smartphone phone = new Smartphone("samsung", 100);

            shop.Add(phone);

            shop.TestPhone("samsung", 50);

            Assert.That(phone.CurrentBateryCharge == 50);

            shop.ChargePhone("samsung");

            Assert.That(phone.CurrentBateryCharge == phone.MaximumBatteryCharge);
        }
    }
}